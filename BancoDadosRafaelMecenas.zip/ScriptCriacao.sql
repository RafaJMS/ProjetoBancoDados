CREATE TABLE Entidades (
    id_entidade integer PRIMARY KEY IDENTITY(1, 1),
    nome varchar(255) Not null,
    tipo varchar(255) DEFAULT 'Pública' ,
    endereco text,
    contato text
);
GO

CREATE TABLE Usuarios (
    id_usuario integer PRIMARY KEY IDENTITY(1, 1),
    nome varchar(255)  Not null,
    email varchar(255)  Not null,
    senha varchar(255)  Not null,
    nivel_permissao varchar(255) DEFAULT 'Baixo',
    id_entidade integer  Not null
);
GO

CREATE TABLE Licitacoes (
    id_licitacao integer PRIMARY KEY IDENTITY(1, 1),
    data_publicacao date  Not null,
    modalidade varchar(255)  Not null,
    id_entidade integer  Not null,
    valor_estimado decimal(20,5)  Not null,
    status varchar(20) DEFAULT 'Ativo'
);
GO

CREATE TABLE Objetos (
    id_objeto integer PRIMARY KEY IDENTITY(1, 1),
    descricao TEXT NOT NULL,
    categoria VARCHAR(255)  Not null,
    valorEstimado DECIMAL(18,2)  Not null,
    quantidade integer  Not null,
    observacoes TEXT,
    id_lote integer  Not null,
    id_fornecedor integer  Not null
);
GO

CREATE TABLE Lotes (
    id_lote integer PRIMARY KEY IDENTITY(1, 1),
    id_licitacao INT  Not null,
    descricao TEXT NOT NULL,
    ValorEstimadoTotal DECIMAL(18, 2)  Not null
);
GO

CREATE TABLE Fornecedores (
    id_fornecedor integer PRIMARY KEY IDENTITY(1, 1),
    nome varchar(255)  Not null,
    tipo varchar(255) DEFAULT 'Jurídica'  Not null,
    doc_identificacao varchar(255)  Not null,
    endereco varchar(255),
    contato varchar(255),
    id_entidade integer  Not null
);
GO

CREATE TABLE Contratos (
    id_contrato integer PRIMARY KEY IDENTITY(1, 1),
    data_inicio date  Not null,
    data_termino date,
    valor decimal(20,5)  Not null,
    status varchar(20) DEFAULT 'Ativo',
    id_entidade integer  Not null,
    id_fornecedor integer  Not null,
    id_objeto integer  Not null
);
GO

ALTER TABLE Usuarios
ADD CONSTRAINT FK_Usuarios_Entidades
FOREIGN KEY (id_entidade) REFERENCES Entidades(id_entidade);

ALTER TABLE Licitacoes
ADD CONSTRAINT FK_Licitacoes_Entidades
FOREIGN KEY (id_entidade) REFERENCES Entidades(id_entidade);

ALTER TABLE Objetos
ADD CONSTRAINT FK_Objetos_Lotes
FOREIGN KEY (id_lote) REFERENCES Lotes(id_lote);

ALTER TABLE Objetos
ADD CONSTRAINT FK_Objetos_Fornecedores
FOREIGN KEY (id_fornecedor) REFERENCES Fornecedores(id_fornecedor);

ALTER TABLE Lotes
ADD CONSTRAINT FK_Lotes_Licitacoes
FOREIGN KEY (id_licitacao) REFERENCES Licitacoes(id_licitacao);

ALTER TABLE Contratos
ADD CONSTRAINT FK_Contratos_Entidades
FOREIGN KEY (id_entidade) REFERENCES Entidades(id_entidade);

ALTER TABLE Contratos
ADD CONSTRAINT FK_Contratos_Fornecedores
FOREIGN KEY (id_fornecedor) REFERENCES Fornecedores(id_fornecedor);

ALTER TABLE Contratos
ADD CONSTRAINT FK_Contratos_Objetos
FOREIGN KEY (id_objeto) REFERENCES Objetos(id_objeto);


